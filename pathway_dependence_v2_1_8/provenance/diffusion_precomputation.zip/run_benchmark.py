"""Frozen local diffusion experiment. Computational outputs, not experimental data."""
import os
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[key]='1'
from pathlib import Path
import argparse, csv, hashlib, itertools, json, platform, time
import numpy as np
import scipy
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve
from scipy.stats import qmc

HERE=Path(__file__).resolve().parent
LEVELS=[8,12,16,24,32,40,48,64]
SEEDS=[2026090601,2026090602,2026090603]
def dump(p,obj):p.write_bytes(json.dumps(obj,indent=2,allow_nan=False).encode('utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def coeff(x,y,xi=None,beta=None):
    if beta is not None:return np.exp(beta*x)+np.zeros_like(y)
    modes=np.stack(np.broadcast_arrays(np.sin(np.pi*x)*np.sin(np.pi*y),
         np.cos(2*np.pi*x)*np.sin(np.pi*y),np.sin(np.pi*x)*np.cos(2*np.pi*y),
         np.sin(2*np.pi*x)*np.sin(2*np.pi*y),np.cos(3*np.pi*x)*np.cos(np.pi*y)))
    return np.exp(.7*np.einsum('k,k...->...',np.asarray(xi)*np.arange(1,6)**(-1.5),modes))

def solve(n,xi=None,beta=None,manufactured=False):
    t=time.perf_counter(); h=1/n
    x,y=np.meshgrid((np.arange(n)+.5)*h,(np.arange(n)+.5)*h,indexing='xy')
    a=coeff(x,y,xi,beta); ids=np.arange(n*n).reshape(n,n)
    diag=np.zeros(n*n); rows=[];cols=[];vals=[]
    for left,right,aa,bb in [(ids[:,:-1],ids[:,1:],a[:,:-1],a[:,1:]),
                             (ids[:-1,:],ids[1:,:],a[:-1,:],a[1:,:])]:
        w=(2*aa*bb/(aa+bb)/h**2).ravel();i=left.ravel();j=right.ravel()
        np.add.at(diag,i,w);np.add.at(diag,j,w)
        rows.extend([i,j]);cols.extend([j,i]);vals.extend([-w,-w])
    for edge,bx,by in [(ids[:,0],np.zeros(n),y[:,0]),
                        (ids[:,-1],np.ones(n),y[:,-1]),
                        (ids[0,:],x[0,:],np.zeros(n)),
                        (ids[-1,:],x[-1,:],np.ones(n))]:
        np.add.at(diag,edge,2*coeff(bx,by,xi,beta)/h**2)
    rows.append(ids.ravel());cols.append(ids.ravel());vals.append(diag)
    mat=coo_matrix((np.concatenate(vals),(np.concatenate(rows),np.concatenate(cols))),shape=(n*n,n*n)).tocsr()
    exact=np.sin(np.pi*x)*np.sin(np.pi*y)
    f=(a*(2*np.pi**2*exact-float(beta or 0)*np.pi*np.cos(np.pi*x)*np.sin(np.pi*y))).ravel() if manufactured else np.ones(n*n)
    v=spsolve(mat,f)
    residual=float(np.linalg.norm(mat@v-f)/np.linalg.norm(f))
    assert np.all(np.isfinite(v)) and residual<=1e-10 and np.min(v)>0
    v=v.reshape(n,n)
    q=[]
    bounds=np.arange(n+1)/n
    for xa,xb,ya,yb in [(.2,.35,.2,.35),(.65,.8,.2,.35),(.2,.35,.65,.8),(.65,.8,.65,.8)]:
        wx=np.maximum(0,np.minimum(bounds[1:],xb)-np.maximum(bounds[:-1],xa))
        wy=np.maximum(0,np.minimum(bounds[1:],yb)-np.maximum(bounds[:-1],ya))
        weights=wy[:,None]*wx[None,:]
        assert abs(weights.sum()-(xb-xa)*(yb-ya))<1e-14
        q.append(float(np.sum(v*weights)/weights.sum()))
    return np.array(q),dict(n=n,residual=residual,elapsed_s=time.perf_counter()-t,
                            l2_error=float(np.sqrt(np.mean((v-exact)**2))) if manufactured else None,
                            minimum_conductivity=float(a.min()),maximum_conductivity=float(a.max()))

def prepare():
    dest=HERE/'results';dest.mkdir(exist_ok=True)
    lock=dest/'FREEZE.json'
    if lock.exists():
        old=json.loads(lock.read_bytes())
        assert old['protocol_sha256']==sha(HERE/'PROTOCOL.md')
        assert old['generator_sha256']==sha(Path(__file__))
        assert old['nodes_sha256']==sha(dest/'pathway_nodes.npz')
        return dest,np.load(dest/'pathway_nodes.npz')['nodes']
    nodes=np.array([2*qmc.Sobol(5,scramble=True,seed=SEEDS[0]).random_base2(5)-1,
                    2*qmc.Halton(5,scramble=True,seed=SEEDS[1]).random(32)-1,
                    2*qmc.LatinHypercube(5,seed=SEEDS[2]).random(32)-1,
                    list(itertools.product([-1/np.sqrt(3),1/np.sqrt(3)],repeat=5))])
    np.savez_compressed(dest/'pathway_nodes.npz',nodes=nodes,weights=np.ones((4,32))/32,levels=LEVELS)
    dump(lock,dict(time_local=time.strftime('%Y-%m-%dT%H:%M:%S%z'),
         protocol_sha256=sha(HERE/'PROTOCOL.md'),generator_sha256=sha(Path(__file__)),
         nodes_sha256=sha(dest/'pathway_nodes.npz'),numpy=np.__version__,scipy=scipy.__version__,
         python=platform.python_version(),platform=platform.platform(),threads=1,
         label='Frozen computational benchmark, not a registry preregistration'))
    return dest,nodes

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--full',action='store_true');args=ap.parse_args()
    d,nodes=prepare()
    if not args.full:
        assert not (d/'pilot.json').exists()
        checks=[]
        for beta in [0.,.3]:
            series=[solve(n,beta=beta,manufactured=True)[1] for n in [8,16,32,64]]
            errors=[r['l2_error'] for r in series]
            order=float(np.log2(errors[-2]/errors[-1]))
            checks.append(dict(beta=beta,series=series,last_order=order))
            dump(d/'manufactured_checks.json',checks)
            assert all(a>b for a,b in zip(errors,errors[1:])) and order>1.5,checks
        rows=[]
        for p in range(4):
            for sample in range(2):
                for n in LEVELS:
                    _,r=solve(n,nodes[p,sample]);r.update(pathway=p,sample=sample);rows.append(r)
        seconds=sum(r['elapsed_s'] for r in rows)
        result=dict(solves=64,elapsed_s=seconds,extrapolated_1024_s=seconds*16,
                    estimate_only=True,max_residual=max(r['residual'] for r in rows),rows=rows)
        dump(d/'pilot.json',result)
        print(json.dumps({k:v for k,v in result.items() if k!='rows'}),flush=True)
        return
    assert (d/'pilot.json').exists()
    assert not (d/'raw_qoi.npz').exists()
    q=np.zeros((4,32,8,4));rows=[];t=time.perf_counter()
    for p in range(4):
        for sample in range(32):
            for l,n in enumerate(LEVELS):
                q[p,sample,l],r=solve(n,nodes[p,sample]);r.update(pathway=p,sample=sample,level=l);rows.append(r)
        print('Completed pathway',p+1,'/4; wall_s',time.perf_counter()-t,flush=True)
    Y=np.concatenate([q.mean(axis=1)[:,:1],np.diff(q,axis=2).mean(axis=1)],axis=1).transpose(1,0,2)
    err=float(np.max(np.linalg.norm(Y.sum(axis=0)-q[:,:,7].mean(axis=1),axis=1)/(1+np.linalg.norm(q[:,:,7].mean(axis=1),axis=1))))
    assert err<1e-12
    np.savez_compressed(d/'raw_qoi.npz',qoi=q)
    np.savez_compressed(d/'cellwise_contributions.npz',Y=Y,direction=np.ones(4)/2)
    with (d/'solve_audit.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    dump(d/'generation_summary.json',dict(solves=len(rows),wall_s=time.perf_counter()-t,
         max_relative_residual=max(r['residual'] for r in rows),telescoping_relative_error=err,
         raw_qoi_sha256=sha(d/'raw_qoi.npz'),cellwise_sha256=sha(d/'cellwise_contributions.npz'),
         data_type='computed stochastic diffusion benchmark; not measured data'))
    print((d/'generation_summary.json').read_text(),flush=True)
if __name__=='__main__':main()
